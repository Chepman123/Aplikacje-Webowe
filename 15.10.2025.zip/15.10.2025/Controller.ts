import {Request, Response} from 'express';
import Service from "./Service";
const html = require('html.html');
export default class Controller{
    constructor(private  service:Service) {
    }
    DefaultPath(req:Request,res:Response){
      res.json(this.service.DefaultPath(req.body.username,req.body.password));
    }
    ChatPath(req:Request,res:Response){
        res.json(this.service.ChatPath(req.params.userId));
    }
    HtmlPath(res:Response){
        res.send(html);
    }
}