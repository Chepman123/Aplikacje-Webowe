const express = require('express');
const routes = require("./Routes");

const app:express = express();

app.use('/',routes);

app.listen(5000);