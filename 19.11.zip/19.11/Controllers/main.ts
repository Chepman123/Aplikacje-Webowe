import Main from "../Service/Main";
import {Request, Response} from "express";

export default  class {
    constructor(private service:Main){}
    getPosts(req:Request,res:Response):void{
       const result = this.service.GetPosts();
       res.json(result);
    }
    addPost(req:Request,res:Response):void{
        this.service.AddPost(req.body.content);
    }
    editPost(req:Request,res:Response):void{
      this.service.EditPost(req.body.id,req.body.content);
    }
}