import {Router} from "express";
import Service from "./Service";
import db from "./db";
import Controller from "./Controller";

export default ()=>{
    const router = Router();

    const service:Service = new Service(db);
    const controller:Controller = new Controller(service);

    router.post('/',(req:Request,res:Response)=>{controller.DefaultPath(req,res)});

    router.get('/Chat',(req:Request,res:Response)=>{controller.ChatPath(req,res)});

    router.get('/html',(req:Request,res:Response)=>{controller.HtmlPath(res)});

    return router
}