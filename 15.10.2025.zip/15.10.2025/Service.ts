import express,{Request, Response} from 'express';
import {QueryError} from "mysql2";
import bcrypt from 'bcrypt';

interface chat{
    chatId:number,
    userId1:number,
    chatIs2:number,
}

export  default  class Service{
    constructor(private  db) {
    }
    DefaultPath(username:string,password:string):Promise<boolean>{
        const sql:string = 'SELECT password FROM users WHERE username = ?';
        return  new Promise<boolean>((resolve,reject)=>{

            this.db.query(sql,[username],(error:QueryError|null,result:{password:string}[])=>{
                if(bcrypt.compare(password,result[0].password)) return resolve(true);
                else return  resolve(false);
            });
        })
    }
    ChatPath(userId):Promise<chat[]>{
        const sql:string = 'SELECT * FROM chats WHERE (userId1 = ?) or (userId2 = ?)';
        return new Promise<chat[]>((resolve,reject)=>{
            this.db.sql(sql,[userId],(error:QueryError|null,result:chat[])=>{
                return resolve(result);
            });
        });
    }
}