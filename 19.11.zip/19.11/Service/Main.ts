const mysql = require("mysql");

class service{
    private db;
    constructor() {
          this.db =  mysql.createConnection(
            {
                host:'localhost',
                user:'root',
                password:'',
                database:'blog',
            }
        );
    }
    async GetPosts(){
       new Promise((resolve,reject)=>{
           const sql = `SELECT * FROM posts`;
           this.db.query(sql,(err,result)=>{
               return resolve(result);
           })
       })
    }
    AddPost(content:string){
        const sql:string = "INSERT INTO posts(content) VALUES(?)";
        this.db.query(sql,[content]);
    }
    EditPost(id:string,content:string){
       const sql:string = "UPDATE posts SET content = ? WHERE id=?";
       this.db.query(sql,[id,content]);
    }
}
module .exports = {service};