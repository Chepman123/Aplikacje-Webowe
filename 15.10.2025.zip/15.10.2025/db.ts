const mysql = require('mysql2');

export default mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'users'
});