var express = require('express');
const service = require("../Service/Main.ts");
const controller = require("../Controllers/Main");
var router = express.Router();

const services = new service();
const controllers = new controller(services);

router.get('/',(req,res)=>{
controllers.getPosts(req,res);
});
router.post('/',(req,res)=>{
    controllers.addPost(req,res);
});
router.put('/',(req,res)=>{
    controllers.editPost(req,res);
});


module.exports = router;